import { NextFunction, Request, Response } from 'express';
import { verify } from 'jsonwebtoken';
import * as dotenv from "dotenv";

dotenv.config();

export function authUser() {
	const secret = process.env.SECRET as string;
	return async (req: Request, res: Response, next: NextFunction) => {
		if (req.headers.authorization) {
			const token = req.headers.authorization.split(' ')[1];
			verify(token, secret, (err, payload) => {
				if (err) {
					next();
				} else if (payload) {
					req.user = payload;
					next();
				}
			});
		} else {
			next();
		}
	}
}
