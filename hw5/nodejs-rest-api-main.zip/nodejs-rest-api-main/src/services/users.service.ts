import * as dotenv from "dotenv";
import { ParsedQs } from 'qs';
import { sign } from 'jsonwebtoken';

import { User } from 'src/entity/User';
import { CreateUserDto } from "../dto/create-user.dto";
import { UserLoginDto } from 'src/dto/user-login.dto';
import { usersRepository } from "../repositories/users.repository";
import { mapDtoToUser, mapUserToDTO } from 'src/dto/mapper';

dotenv.config();

class UsersService {
  async createUser(dto: CreateUserDto): Promise<User> {
    const newUser = mapDtoToUser(dto);
    const salt = process.env.SALT as string;

		await newUser.setPassword(dto.password, Number(salt));    
    return usersRepository.create(newUser);
  }

  async countUsers(): Promise<number> {
    return usersRepository.count();
  }

  async getAll(query: ParsedQs, page: number, limit: number): Promise<User[]> {
    return usersRepository.findAll(query, page, limit);
  }

  async getOne(id: number): Promise<User | null> {
    return usersRepository.findById(id);
  }

  async deleteUser(id: number): Promise<User | null> {
    const user = await this.getOne(id);
    return user ? usersRepository.delete(user) : null;
  }

  async updateUser(id: number, dto: CreateUserDto): Promise<User | null> {
    return usersRepository.update(id, dto);
  }

  async validateUser({ password, email }: UserLoginDto): Promise<boolean> {
    const existedUser = await usersRepository.findByEmail(email);
    
    if (!existedUser) {
      return false;
    }

    const newUser = new User();
    newUser.password = existedUser.password;
    
    return newUser.comparePassword(password);
  }

  async signJWT(email: string, secret: string): Promise<string> {
    return new Promise<string>((res, rej) => {
      sign(
        {
          email,
          iat: Math.floor(Date.now() / 1000),
        },
        secret,
        {
          algorithm: 'HS256',
        },
        (err, token) => {
          if (err) {
            rej(err);
          }
          res(token as string);
        },
      );
    });
  }
}

export const usersService = new UsersService();
