import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    BaseEntity,
    OneToMany,
} from 'typeorm';
import { Post } from './Post';
import { compare, hash } from 'bcryptjs';


@Entity('users')
export class User extends BaseEntity {
    @PrimaryGeneratedColumn('increment')
    id = 0;

    @Column({ unique: true })
    username: string = "";

    @Column()
    email: string = "";

    @Column()
    age: number = 0;

    @Column({ nullable: true })
    info?: string;

    @Column('json', { nullable: true })
    address?: {
        city: string;
        street: string;
    };

    @OneToMany(() => Post, post => post.user)
    posts?: Post[];

    @Column()
    password: string = "";

    public async setPassword(pass: string, salt: number): Promise<void> {
		this.password = await hash(pass, salt);
	}

	public async comparePassword(pass: string): Promise<boolean> {
		return await compare(pass, this.password);
	}
}