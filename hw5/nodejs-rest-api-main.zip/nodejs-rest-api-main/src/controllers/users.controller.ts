import { Router } from "express";

import { asyncWrapper } from "src/shared/middlewares/async-wrapper";
import { validateReq } from "src/shared/middlewares/validate";
import { authUser } from 'src/shared/middlewares/user-auth';

import { usersService } from "../services/users.service";
import { CreateUserDto } from "../dto/create-user.dto";
import { mapUserToDTO } from '../dto/mapper';

const router = Router();

router.get(
    "/",
    authUser(),
    asyncWrapper(async ({ query }, res) => {
        const page = 1, limit = 10;
        const users = await usersService.getAll(query, page, limit);
        const totalUsers = await usersService.countUsers();
        const userDTOs = users.map((user) => mapUserToDTO(user));

        res.status(200).json({
            users: userDTOs,
            totalUsers,
            page: Number(page),
            totalPages: Math.ceil(totalUsers / Number(limit)),
        });
    })
)

router.get(
    "/:id",
    authUser(),
    asyncWrapper(async ({ params }, res) => {
        const user = await usersService.getOne(parseInt(params.id, 10));
        if (!user) {
            res.status(400).send("User not exist");
            return;
        }
        res.status(200).send(mapUserToDTO(user)).json();
    })
);

router.post(
    "/login",
    asyncWrapper(async (req, res) => {
        const result = await usersService.validateUser(req.body);
		if (!result) {
			res.status(401).send({ error: 'Auth error' });
            return;
		}
		const jwt = await usersService.signJWT(req.body.email, process.env.SECRET as string);
		res.status(200).send({ jwt });
    })
);

router.post(
    "/",
    validateReq(CreateUserDto),
    asyncWrapper(async (req, res) => {
        const user = await usersService.createUser(req.body);
        res.status(201).send(mapUserToDTO(user));
    })
);

router.delete(
    "/:id",
    authUser(),
    asyncWrapper(async ({ params }, res) => {
        const user = await usersService.deleteUser(parseInt(params.id, 10));
        if (!user) {
            res.status(400).send("User not exist");
            return;
        }
        res.status(200).send(mapUserToDTO(user)).json();
    })
);

router.put(
    "/:id",
    authUser(),
    asyncWrapper(async ({ params, body }, res) => {
        const user = await usersService.updateUser(parseInt(params.id, 10), body);
        if (!user) {
            res.status(400).send("User not exist");
            return;
        }
        res.status(200).send(mapUserToDTO(user)).json();
    })
);

export const usersController = router;